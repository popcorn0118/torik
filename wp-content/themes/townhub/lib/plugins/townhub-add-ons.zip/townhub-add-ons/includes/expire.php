<?php 
/* add_ons_php */



// add_action( 'admin_init', function(){
//     $listings = get_posts( array(
//         'fields'            => 'ids', 
//         'posts_per_page'    => -1, 
//         'post_type'         => 'listing',
//         'post_status'       => 'pending',
//     ) );
//     if ( $listings ) {
//         foreach ( $listings as $lid ) {
//             wp_update_post(array('ID' => $lid, 'post_status' => 'publish');
//         }
//     }
// } );

    

